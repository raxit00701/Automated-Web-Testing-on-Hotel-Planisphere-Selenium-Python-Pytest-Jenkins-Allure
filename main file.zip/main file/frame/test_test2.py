# test_signup_icon_delete_e2e.py
import pytest
from time import sleep
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select, WebDriverWait
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.alert import Alert
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from pom.Homepage import HomePage


def open_home(driver, base_url):
    HomePage(driver).open_home(base_url).click_signup_link()
    print("➡️ Opened Sign up page")


def fill_form(driver, wait, data):
    # Email
    email = wait.until(EC.visibility_of_element_located((By.ID, "email")))
    email.clear()
    email.send_keys(data["email"])
    print("📧 Email entered")

    # Passwords
    pwd = driver.find_element(By.ID, "password")
    pwd.clear(); pwd.send_keys(data["password"])
    pwdc = driver.find_element(By.ID, "password-confirmation")
    pwdc.clear(); pwdc.send_keys(data["password_confirmation"])

    # Username
    uname = driver.find_element(By.ID, "username")
    uname.clear(); uname.send_keys(data["username"])

    # Rank (radio)
    driver.find_element(By.ID, "rank-normal").click()

    # Address & Tel
    addr = driver.find_element(By.ID, "address")
    addr.clear(); addr.send_keys(data["address"])
    tel = driver.find_element(By.ID, "tel")
    tel.clear(); tel.send_keys(data["tel"])

    # Gender (select)
    Select(driver.find_element(By.ID, "gender")).select_by_value(str(data["gender"]))

    # Birthday (date input)
    bday = driver.find_element(By.ID, "birthday")
    bday.clear()
    try:
        bday.send_keys(data["birthday"])  # works if type=date accepts typing
    except Exception:
        # fallback: set via JS
        driver.execute_script("arguments[0].value = arguments[1];", bday, data["birthday"])

    # Notification (checkbox)
    notif = driver.find_element(By.ID, "notification")
    if not notif.is_selected():
        notif.click()

    # Submit
    driver.find_element(By.CSS_SELECTOR, "button[type='submit']").click()
    print("📝 Submitted signup form")


def rgb_to_hex(r, g, b):
    return f'#{r:02x}{g:02x}{b:02x}'


def wait_clickable(wait, locator, timeout=10):
    return WebDriverWait(wait._driver, timeout).until(EC.element_to_be_clickable(locator))


@pytest.mark.order(1)
def test_signup_icon_delete_e2e(driver, wait, base_url):
    # ---------- Go to Sign up ----------
    open_home(driver, base_url)

    invalid_data = {
        "email": "invalid-email",
        "password": "123",
        "password_confirmation": "123!",
        "username": "!!@@##",
        "address": "???",
        "tel": "abcd",
        "gender": "1",
        "birthday": "2025-09-13",
    }

    valid_data = {
        "email": "testuser@example.com",
        "password": "StrongPass123!",
        "password_confirmation": "StrongPass123!",
        "username": "TestUser",
        "address": "123 Main Street",
        "tel": "01133335555",
        "gender": "1",
        "birthday": "1990-01-01",
    }

    # ---------- Invalid case ----------
    print("🚫 Running invalid test case")
    fill_form(driver, wait, invalid_data)
    # Optional: assert an error message appears (adjust selector/text to your app)
    sleep(1)
    possible_errs = driver.find_elements(By.CSS_SELECTOR, ".invalid-feedback, .alert, .error, .toast")
    if possible_errs:
        print("❗ Validation errors shown (as expected for invalid data).")
    else:
        print("ℹ️ No visible error container found; app may block silently or inline.")

    # ---------- Valid case ----------
    driver.refresh()
    print("✅ Running valid test case")
    # Re-open Sign up if refresh redirects away
    try:
        wait.until(EC.visibility_of_element_located((By.ID, "email")))
    except TimeoutException:
        open_home(driver, base_url)

    fill_form(driver, wait, valid_data)
    sleep(1)

    # ---------- Icon upload page ----------
    # Step 1: Click the icon link
    icon_link = wait.until(EC.element_to_be_clickable((By.XPATH, "//a[@id='icon-link']")))
    icon_link.click()
    print("🖼️ Navigated to Icon settings")
    sleep(1)

    # Step 2: Upload file
    file_input = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, "#icon")))
    file_input.send_keys(r"D:\test.png")  # adjust to a valid path on your machine/CI
    print("📤 File uploaded")
    driver.execute_script("window.scrollBy(0, 100);")

    # Zoom bar interaction
    zoom_bar = wait.until(EC.visibility_of_element_located((By.XPATH, "//input[@id='zoom']")))
    actions = ActionChains(driver)
    actions.click_and_hold(zoom_bar).move_by_offset(-20, 0).pause(0.5).release().perform()
    print("🔍 Zoom bar moved left")

    # Color picker
    hex_color = rgb_to_hex(0, 0, 0)  # #000000
    color_input = driver.find_element(By.XPATH, "//input[@id='color']")
    color_input.clear(); color_input.send_keys(hex_color)
    print(f"🎨 Color {hex_color} inserted")

    # Submit icon settings
    submit_button = driver.find_element(By.XPATH, "//button[normalize-space()='submit' or normalize-space()='Submit']")
    submit_button.click()
    print("📨 Submitted icon settings")
    sleep(1)

    # ---------- Delete account flow ----------
    delete_btn = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, "button.btn.btn-danger.btn-block.my-3")))
    delete_btn.click()
    print("🗑️ Clicked delete account")
    sleep(1)

    # Handle up to two alerts (confirmations)
    try:
        alert = Alert(driver)
        print(f"⚠️ Alert text: {alert.text}")
        alert.accept()
        print("🖱️ Clicked OK on first alert")
        sleep(0.5)
        # Some UIs chain another alert
        try:
            alert = Alert(driver)
            print(f"⚠️ Alert text: {alert.text}")
            alert.accept()
            print("🖱️ Clicked OK on second alert")
        except Exception:
            pass
    except Exception as e:
        print(f"✅ No alert or already handled: {e}")

    print("🎯 End-to-end signup → icon → delete flow completed.")
