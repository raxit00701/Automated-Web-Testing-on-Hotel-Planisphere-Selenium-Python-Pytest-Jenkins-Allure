import allure

def test_allure_sanity():
    with allure.step("Step A"):
        x = 2 + 2
    with allure.step("Step B"):
        assert x == 4