# test_login_flow_dd_fixed.py
import pytest
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import TimeoutException
from time import sleep
from pom.Homepage import HomePage

DATA_SETS = [
    {
        "label": "invalid_creds",
        "email": "wrong@example.com",
        "password": "wrongpass",
        "expect_success": False,
        "expected_error_contains": "Invalid",  # tweak for your app or remove
    },
    {
        "label": "valid_creds",
        "email": "clark@example.com",
        "password": "password",
        "expect_success": True,
    },
]

def open_home(driver, base_url):
    HomePage(driver).open_home(base_url).click_login_link()
    print("Step 1: Clicked on Login link")

def do_login(driver, wait, email, password):
    email_el = wait.until(EC.presence_of_element_located((By.ID, "email")))
    email_el.clear(); email_el.send_keys(email)
    pwd_el = wait.until(EC.presence_of_element_located((By.ID, "password")))
    pwd_el.clear(); pwd_el.send_keys(password)
    wait.until(EC.element_to_be_clickable((By.ID, "login-button"))).click()

def is_logout_visible(driver, timeout=5):
    """Use a fresh WebDriverWait; .with_timeout() doesn't exist."""
    try:
        short_wait = WebDriverWait(driver, timeout)
        return short_wait.until(
            EC.visibility_of_element_located((By.XPATH, "//button[normalize-space()='Logout']"))
        )
    except TimeoutException:
        return None

def get_error_text_if_any(driver):
    selectors = [
        (By.CSS_SELECTOR, ".alert, .error, .toast, .invalid-feedback"),
        (By.XPATH, "//*[contains(@class,'error') or contains(@class,'alert') or contains(@class,'toast')]"),
        (By.ID, "login-error"),
    ]
    for by, sel in selectors:
        els = driver.find_elements(by, sel)
        if els:
            text = " ".join(e.text for e in els if e.text).strip()
            if text:
                return text
    return ""

@pytest.mark.parametrize("data", DATA_SETS, ids=[d["label"] for d in DATA_SETS])
def test_login_flow_data_sets(driver, wait, base_url, data):
    # Step 1: Open login page
    open_home(driver, base_url)

    # Step 2/3: Attempt login with provided dataset
    do_login(driver, wait, data["email"], data["password"])
    sleep(1)  # small settle; prefer explicit waits where possible

    # Detect success by presence of Logout
    logout_btn = is_logout_visible(driver, timeout=5)

    if data["expect_success"]:
        assert logout_btn, "Expected login success, but 'Logout' button not visible."
        logout_btn.click()
        print(f"[{data['label']}] ✅ Logged in & out successfully.")
    else:
        assert not logout_btn, "Expected login failure, but 'Logout' appeared (user seems logged in)."
        err = get_error_text_if_any(driver)
        exp = data.get("expected_error_contains")
        if exp:
            assert exp.lower() in err.lower(), f"Expected error to contain '{exp}', got: '{err}'"
        print(f"[{data['label']}] ❌ Login blocked as expected. Error: {err or 'N/A'}")

    print(f"🧹 Test complete for dataset: {data['label']}")
