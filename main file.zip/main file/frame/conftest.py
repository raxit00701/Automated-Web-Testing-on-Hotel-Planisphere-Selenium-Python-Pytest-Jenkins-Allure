# conftest.py
import os
import re
import time
import base64
import pytest
import builtins
import allure

from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait

# --- Folders (next to this conftest) ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SCREENSHOTS_DIR = os.path.join(BASE_DIR, "screenshots")
LOGS_DIR = os.path.join(BASE_DIR, "logger")
os.makedirs(SCREENSHOTS_DIR, exist_ok=True)
os.makedirs(LOGS_DIR, exist_ok=True)

pytest_html = None  # (optional) only used if you also generate pytest-html


def safe_filename(name: str) -> str:
    """Replace unsafe path chars so we can use nodeid in file names."""
    return re.sub(r'[\\/:*?"<>|]', "_", name)


@pytest.fixture
def driver():
    options = webdriver.ChromeOptions()
    # enable browser console logs for Chrome
    options.set_capability("goog:loggingPrefs", {"browser": "ALL"})
    # always incognito
    options.add_argument("--incognito")
    # options.add_argument("--headless=new")  # enable in CI if needed

    d = webdriver.Chrome(options=options)
    d.maximize_window()
    yield d
    d.quit()


@pytest.fixture
def base_url():
    return "https://hotel-example-site.takeyaqa.dev/en-US/"


def _embed_image_as_html(path: str) -> str:
    """Return an <img> tag with base64 so it shows inline in self-contained html."""
    with open(path, "rb") as f:
        b64 = base64.b64encode(f.read()).decode("utf-8")
    return f'<img src="data:image/png;base64,{b64}" style="max-width:500px;height:auto" onclick="window.open(this.src)" />'


def _attach_to_allure_safely(name: str, data: bytes | str, a_type):
    """Guarded Allure attach."""
    try:
        allure.attach(data, name=name, attachment_type=a_type)
    except Exception:
        pass


@pytest.hookimpl(hookwrapper=True, tryfirst=True)
def pytest_runtest_makereport(item, call):
    """
    After each phase, add the result object back to the test item.
    We’ll use it in the autouse fixture to decide when to attach artifacts.
    """
    outcome = yield
    rep = outcome.get_result()
    setattr(item, f"rep_{rep.when}", rep)


@pytest.fixture(autouse=True)
def _attach_artifacts_on_failure(request, driver):
    """
    Automatically attach artifacts to Allure when a test fails:
      - Screenshot (PNG)
      - Browser console logs (TEXT)
      - Current URL (TEXT)
      - Page source (HTML, small/medium pages)
    Also keeps saving PNG+logs to disk like before.
    """
    yield

    # Did the test fail during the call phase?
    rep = getattr(request.node, "rep_call", None)
    if not rep or not rep.failed:
        return

    ts = time.strftime("%Y%m%d_%H%M%S")
    base = safe_filename(request.node.nodeid.replace("::", "__"))
    png_path = os.path.join(SCREENSHOTS_DIR, f"{base}_{ts}.png")
    log_path = os.path.join(LOGS_DIR, f"{base}_{ts}.log")

    # Screenshot (disk + Allure)
    png_ok = False
    try:
        driver.save_screenshot(png_path)
        png_ok = True
        with open(png_path, "rb") as f:
            _attach_to_allure_safely("failure-screenshot", f.read(), allure.attachment_type.PNG)
    except Exception:
        pass

    # Current URL
    try:
        _attach_to_allure_safely("current-url", driver.current_url, allure.attachment_type.TEXT)
    except Exception:
        pass

    # Page source (can be big; Allure trims display)
    try:
        _attach_to_allure_safely("page-source", driver.page_source, allure.attachment_type.HTML)
    except Exception:
        pass

    # Browser console logs (disk + Allure)
    logs = []
    try:
        logs = driver.get_log("browser")
    except Exception:
        pass

    with open(log_path, "w", encoding="utf-8") as f:
        if logs:
            for e in logs:
                level = e.get("level", "")
                msg = e.get("message", "")
                f.write(f"{level} - {msg}\n")
        else:
            f.write("No browser logs captured.\n")

    # Also attach logs to Allure
    try:
        with open(log_path, "r", encoding="utf-8") as f:
            _attach_to_allure_safely("browser-console", f.read(), allure.attachment_type.TEXT)
    except Exception:
        pass

    # Console note (so you see file locations in terminal too)
    if png_ok:
        print(f"\n🖼️ Screenshot saved: {png_path}")
    print(f"📂 Logs saved: {log_path}")

    # Optional: if you also use pytest-html, add inline screenshot + link to logs
    if pytest_html:
        extra = getattr(rep, "extra", [])
        if png_ok:
            extra.append(pytest_html.extras.html(_embed_image_as_html(png_path)))
        extra.append(pytest_html.extras.url(f"file://{log_path}", name="Browser Logs"))
        rep.extra = extra


def pytest_configure(config):
    # get pytest-html plugin object if present (optional)
    global pytest_html
    pytest_html = config.pluginmanager.getplugin("html")

    # Write Allure environment.properties to the results dir (if provided)
    alluredir = config.getoption("--alluredir")
    if alluredir:
        try:
            os.makedirs(alluredir, exist_ok=True)
            env_file = os.path.join(alluredir, "environment.properties")
            with open(env_file, "w", encoding="utf-8") as f:
                f.write("Browser=Chrome\n")
                f.write(f"BaseURL={os.getenv('BASE_URL','https://hotel-example-site.takeyaqa.dev/en-US/')}\n")
                f.write("OS=Windows\n")
        except Exception:
            pass


@pytest.fixture(autouse=True)
def _inject_globals(driver, base_url):
    builtins.driver = driver
    builtins.base_url = base_url
    try:
        yield
    finally:
        builtins.driver = None
        builtins.base_url = None


@pytest.fixture
def wait(driver):
    # tune the timeout as you like
    return WebDriverWait(driver, 15)
