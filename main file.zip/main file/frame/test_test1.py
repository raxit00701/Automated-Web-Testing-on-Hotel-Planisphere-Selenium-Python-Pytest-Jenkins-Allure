# test_reservation_flow_dd.py
import pytest
from time import sleep
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait, Select
from selenium.webdriver.support import expected_conditions as EC
from pom.Homepage import HomePage

# ---- Test Data (each item is one scenario) ----
DATA_SETS = [
    {
        "label": "happy_path_email",
        "date": "10",
        "term": "3",
        "head_count": "2",
        "addons": ["breakfast", "early-check-in", "sightseeing"],
        "username": "john wick",
        "contact": "email",  # valid values: "email", "tel", etc. (as per app)
        "email": "johnwick@example.com",
        "comment": "this is testing",
    },
    {
        "label": "happy_path_phone",
        "date": "15",
        "term": "2",
        "head_count": "3",
        "addons": ["breakfast"],
        "username": "bruce wayne",
        "contact": "email",
        "email": "bruce@wayneenterprises.com",
        "comment": "reserve for board meeting",
    },
]

def open_home(driver, base_url):
    page = HomePage(driver)
    page.open_home(base_url).click_reserve_link()

def _scroll(driver, px=700, times=3):
    for _ in range(times):
        driver.execute_script(f"window.scrollBy(0, {px});")

def _click_reserve_button(driver, wait):
    locator = (
        By.XPATH,
        "//div[contains(@class,'card')]//a[contains(@href,'reserve.html') and contains(normalize-space(),'Reserve room')]",
    )
    btn = wait.until(EC.element_to_be_clickable(locator))
    assert btn.is_displayed(), "Reserve button not visible"
    btn.click()
    return btn

def _switch_to_last_tab(driver):
    if len(driver.window_handles) > 1:
        driver.switch_to.window(driver.window_handles[-1])

def _pick_date(driver, day_text):
    # open date picker then click specific date
    driver.find_element(By.ID, "date").click()
    driver.find_element(By.XPATH, f"//a[normalize-space()='{day_text}']").click()

def _fill_form(driver, data):
    # term
    term = driver.find_element(By.ID, "term")
    term.clear()
    term.send_keys(str(data["term"]))

    # head-count
    head = driver.find_element(By.ID, "head-count")
    head.clear()
    head.send_keys(str(data["head_count"]))

    # addons (checkboxes)
    for cid in data.get("addons", []):
        cb = driver.find_element(By.ID, cid)
        if not cb.is_selected():
            cb.click()

    # username
    driver.find_element(By.ID, "username").send_keys(data["username"])
    driver.execute_script("window.scrollBy(0, 200);")

    # contact method
    Select(driver.find_element(By.ID, "contact")).select_by_value(data["contact"])

    # email (if visible for chosen contact)
    if data.get("email"):
        driver.find_element(By.ID, "email").send_keys(data["email"])

    # comment
    driver.find_element(By.ID, "comment").send_keys(data["comment"])

def _submit_and_close(driver, wait):
    # main submit
    driver.find_element(By.ID, "submit-button").click()
    # final submit on modal
    wait.until(EC.element_to_be_clickable((By.XPATH, "//button[normalize-space()='Submit Reservation']"))).click()
    # wait for confirmation to appear then close
    close_btn = wait.until(EC.element_to_be_clickable((By.XPATH, "//button[normalize-space()='Close']")))
    sleep(1)
    close_btn.click()

@pytest.mark.parametrize("data", DATA_SETS, ids=[d["label"] for d in DATA_SETS])
def test_reservation_flow_data_driven(driver, base_url, data):
    """
    Data-driven reservation flow using dictionaries.
    Requires 'driver' and 'base_url' fixtures (from your conftest.py).
    """
    wait = WebDriverWait(driver, 10)

    # 1) Open homepage -> Reserve section
    open_home(driver, base_url)

    # 2) Scroll down for visibility
    _scroll(driver, times=3)

    # 3) Click a specific "Reserve room" button
    _click_reserve_button(driver, wait)
    sleep(1)

    # 4) Switch to new tab (if one opened)
    _switch_to_last_tab(driver)

    # 5) Pick date from calendar (e.g., "10")
    _pick_date(driver, data["date"])
    sleep(0.5)

    # 6–12) Fill the form from dict
    _fill_form(driver, data)
    driver.execute_script("window.scrollBy(0, -400);")

    # 13–15) Submit and close confirmation
    _submit_and_close(driver, wait)
    sleep(1)
