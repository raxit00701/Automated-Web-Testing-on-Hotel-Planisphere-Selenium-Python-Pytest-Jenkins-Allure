# Base/BaseTest.py
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.select import Select
from selenium.webdriver.support import expected_conditions as EC

try:
    from selenium.webdriver.chrome.service import Service
    from webdriver_manager.chrome import ChromeDriverManager
    _USE_WDM = True
except Exception:
    Service = None
    ChromeDriverManager = None
    _USE_WDM = False


class Base:
    """Tiny wrapper so you don't repeat setup every time."""
    def __init__(
        self,
        url: str = "https://hotel-example-site.takeyaqa.dev/en-US/",
        *,
        detach: bool = True,
        headless: bool = False,
        wait_timeout: int = 20,
        incognito: bool = True,  # <- default to incognito for every run
    ):
        opts = Options()
        if detach:
            opts.add_experimental_option("detach", True)
        if headless:
            # use new headless for Chrome 109+
            opts.add_argument("--headless=new")
        opts.add_argument("--start-maximized")

        # --- Incognito mode for every test ---
        if incognito:
            opts.add_argument("--incognito")
            # Optional hardening to keep the session clean
            opts.add_argument("--no-first-run")
            opts.add_argument("--no-default-browser-check")
            # Ensure a fresh temp profile each run (Chrome does this in incognito anyway)
            # but we explicitly avoid user-data-dir so no persisted profile is used.

        if _USE_WDM:
            service = Service(ChromeDriverManager().install())
            self.driver = webdriver.Chrome(service=service, options=opts)
        else:
            self.driver = webdriver.Chrome(options=opts)

        self.wait = WebDriverWait(self.driver, wait_timeout)
        self.actions = ActionChains(self.driver)

        # open default URL immediately
        self.driver.get(url)

    # ---- helpers ----
    def find(self, by, value, timeout: int | None = None):
        if timeout:
            return WebDriverWait(self.driver, timeout).until(EC.presence_of_element_located((by, value)))
        return self.wait.until(EC.presence_of_element_located((by, value)))

    def click(self, by, value, timeout: int | None = None):
        w = WebDriverWait(self.driver, timeout) if timeout else self.wait
        el = w.until(EC.element_to_be_clickable((by, value)))
        el.click()
        return el

    def type(self, by, value, text, clear=True):
        el = self.find(by, value)
        if clear:
            el.clear()
        el.send_keys(text)
        return el

    def quit(self):
        self.driver.quit()


# re-export
__all__ = ["Base", "By", "Keys", "EC", "WebDriverWait", "Select", "ActionChains"]
