from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from time import sleep

class HomePage:
    # Locators
    RESERVE_LINK = (By.XPATH, "//a[@href='./plans.html' and normalize-space()='Reserve']")
    SIGNUP_LINK = (By.XPATH, "//a[normalize-space()='Sign up']")
    LOGIN_LINK = (By.XPATH, "//a[normalize-space()='Login']")

    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(self.driver, 10)

    def open_home(self, base_url):
        self.driver.get(base_url)
        return self

    def click_reserve_link(self):
        self.driver.find_element(*self.RESERVE_LINK).click()
        print("Clicked on 'Reserve' link")
        sleep(10)  # Retaining sleep as per original script
        return self

    def click_signup_link(self):
        self.driver.find_element(*self.SIGNUP_LINK).click()
        print("📝 Clicked 'Sign up'")
        return self

    def click_login_link(self):
        self.wait.until(EC.element_to_be_clickable(self.LOGIN_LINK)).click()
        print("Step 1: Clicked on Login link")
        return self

    def is_reserve_link_displayed(self):
        return self.driver.find_element(*self.RESERVE_LINK).is_displayed()