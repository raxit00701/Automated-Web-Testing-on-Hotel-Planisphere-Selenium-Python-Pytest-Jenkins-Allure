from selenium.webdriver.common.by import By
from selenium import webdriver
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.alert import Alert
from selenium.webdriver.support.ui import WebDriverWait
from Base.Base import Base
from selenium.webdriver.chrome.options import Options
from time import sleep
import time
from selenium.common.exceptions import TimeoutException, NoAlertPresentException

# Initialize driver
bt = Base()
driver = bt.driver
wait = WebDriverWait(driver, 15)





# Step 1: Just click Login button (without entering anything)
wait.until(EC.element_to_be_clickable((By.XPATH, "//a[normalize-space()='Login']"))).click()
print("Step 1: Clicked on Login link")
wait.until(EC.element_to_be_clickable((By.ID, "login-button"))).click()
# Step 2: Try with invalid values
email_field = wait.until(EC.presence_of_element_located((By.ID, "email")))
email_field.clear()
email_field.send_keys("wrong@example.com")

password_field = wait.until(EC.presence_of_element_located((By.ID, "password")))
password_field.clear()
password_field.send_keys("wrongpass")

wait.until(EC.element_to_be_clickable((By.ID, "login-button"))).click()
print("Step 2: Tried with invalid values")

# /* """Step 3: Try with valid values
# email_field = wait.until(EC.presence_of_element_located((By.ID, "email")))
email_field.clear()
email_field.send_keys("clark@example.com")

password_field = wait.until(EC.presence_of_element_located((By.ID, "password")))
password_field.clear()
password_field.send_keys("password")

wait.until(EC.element_to_be_clickable((By.ID, "login-button"))).click()
print("Step 3: Tried with valid values")
sleep(3)

log_out=driver.find_element(By.XPATH,"//button[normalize-space()='Logout']").click()
print("Step 4: Logged out successfully")





driver.quit()
print("🧹 Driver quit. Test complete.")
