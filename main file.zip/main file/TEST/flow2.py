from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait, Select
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.alert import Alert
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By


from Base.Base import Base
from time import sleep
from selenium.webdriver.support.ui import WebDriverWait, Select


# Initialize driver
bt = Base()
driver = bt.driver
wait = WebDriverWait(driver, 15)

# Test data
invalid_data = {
    "email": "invalid-email",
    "password": "123",
    "password-confirmation": "123!",
    "username": "!!@@##",
    "address": "???",
    "tel": "abcd",
    "gender": "1",
    "birthday": "2025-09-13"
}

valid_data = {
    "email": "testuser@example.com",
    "password": "StrongPass123!",
    "password-confirmation": "StrongPass123!",
    "username": "TestUser",
    "address": "123 Main Street",
    "tel": "01133335555",
    "gender": "1",
    "birthday": "1990-01-01"
}

def fill_form(data):
    driver.find_element(By.XPATH, "//a[normalize-space()='Sign up']").click()
    print("📝 Clicked 'Sign up'")

    email = wait.until(EC.visibility_of_element_located((By.ID, "email")))
    assert email.is_displayed(), "❌ Email field not visible"
    email.send_keys(data["email"])
    print("📧 Email entered")

    password = driver.find_element(By.ID, "password")
    assert password.is_enabled(), "❌ Password field not enabled"
    password.send_keys(data["password"])
    print("🔐 Password entered")

    confirm = driver.find_element(By.ID, "password-confirmation")
    assert confirm.is_enabled(), "❌ Confirm password field not enabled"
    confirm.send_keys(data["password"])
    print("✅ Password confirmed")

    username = driver.find_element(By.ID, "username")
    assert username.is_enabled(), "❌ Username field not enabled"
    username.send_keys(data["username"])
    print("👤 Username entered")

    rank = driver.find_element(By.ID, "rank-normal")
    assert rank.is_displayed(), "❌ Rank button not visible"
    rank.click()
    print("🎖️ Rank selected")

    address = driver.find_element(By.ID, "address")
    assert address.is_enabled(), "❌ Address field not enabled"
    address.send_keys(data["address"])
    print("🏠 Address entered")

    tel = driver.find_element(By.ID, "tel")
    assert tel.is_enabled(), "❌ Telephone field not enabled"
    tel.send_keys(data["tel"])
    print("📞 Telephone entered")

    gender = Select(driver.find_element(By.ID, "gender"))
    gender.select_by_value(data["gender"])
    print("⚧️ Gender selected")

    birthday = driver.find_element(By.ID, "birthday")
    assert birthday.is_enabled(), "❌ Birthday field not enabled"
    birthday.send_keys(data["birthday"])
    print("🎂 Birthday entered")

    notification = driver.find_element(By.ID, "notification")
    notification.click()
    print("🔔 Notification toggled")

    submit = driver.find_element(By.CSS_SELECTOR, "button[type='submit']")
    assert submit.is_enabled(), "❌ Submit button not enabled"
    submit.click()
    print("🚀 Form submitted")

def clear_form():
    fields = ["email", "password", "username", "address", "tel", "birthday"]
    for field in fields:
        elem = driver.find_element(By.ID, field)
        elem.clear()
        print(f"🧹 Cleared {field}")

    Select(driver.find_element(By.ID, "gender")).select_by_index(0)
    print("🔄 Gender reset")

    driver.find_element(By.ID, "notification").click()
    print("🔕 Notification untoggled")

# Run invalid test
print("🚫 Running invalid test case")
fill_form(invalid_data)
sleep(2)

# Clear and retry with valid data
print("🔄 Clearing form for valid test")
clear_form()
sleep(1)

print("✅ Running valid test case")
fill_form(valid_data)






# Step 1: Click the icon link
icon_settings = driver.find_element(By.XPATH, "//a[@id='icon-link']")
icon_settings.click()
sleep(4)

# Step 2: Locate the file input element and upload the file
file_input = driver.find_element(By.CSS_SELECTOR, "#icon")
file_input.send_keys(r"D:\test.png")
print("Assertion: File uploaded successfully")
driver.execute_script("window.scrollBy(0, 100);")
print("Scrolled up slightly")
zoom_bar = driver.find_element(By.XPATH, "//input[@id='zoom']")

# Create action chain
actions = ActionChains(driver)

# Click and hold, move left slightly, then release
actions.click_and_hold(zoom_bar).move_by_offset(-20, 0).pause(1).release().perform()

print("Assertion: Zoom bar moved left")

def rgb_to_hex(r, g, b):
    return '#{:02x}{:02x}{:02x}'.format(r, g, b)

# Example RGB: (255, 100, 50)
hex_color = rgb_to_hex(0, 0, 0)

# Locate and insert color
color_input = driver.find_element(By.XPATH, "//input[@id='color']")
color_input.send_keys(hex_color)

print(f"Assertion: Color {hex_color} inserted successfully")



submit_button = driver.find_element(By.XPATH,"//button[normalize-space()='submit']").click()
print("clicked submit button")
sleep(2)
delete_account = driver.find_element(By.CSS_SELECTOR, "button[class='btn btn-danger btn-block my-3']")
delete_account.click()
sleep(4)
print("account has been deleted")
try:
    alert = Alert(driver)
    print(f"⚠️ Alert text: {alert.text}")
    alert.accept()
    print("🖱️ Clicked OK on alert")

    sleep(1)
    print(f"⚠️ Alert text: {alert.text}")
    alert.accept()
    print("🖱️ Clicked OK on second alert")
except Exception as e:
    print(f"✅ No alert appeared or already handled: {e}")

sleep(2)
driver.quit()

