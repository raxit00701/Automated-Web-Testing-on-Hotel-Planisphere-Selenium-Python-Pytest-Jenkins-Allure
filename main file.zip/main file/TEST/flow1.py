from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import Select
from Base.Base import Base
import time
from time import sleep

bt = Base()
driver = bt.driver
wait = WebDriverWait(driver, 15)

# Click on "Reserve" link
reserve_link = driver.find_element(By.XPATH, "//a[@href='./plans.html' and normalize-space()='Reserve']")
assert reserve_link.is_displayed(), "Reserve link not visible"
reserve_link.click()
print("Clicked on 'Reserve' link")
sleep(10)

# Scroll down
for _ in range(3):
    driver.execute_script("window.scrollBy(0, 700);")
print("Scrolled down 3 times")

# Click on specific reserve button
reserve_btn = driver.find_element(By.XPATH, "//div[contains(@class,'card')]//a[contains(@href,'reserve.html') and contains(normalize-space(),'Reserve room')]")
assert reserve_btn.is_displayed(), "Reserve button not visible"
reserve_btn.click()
print("Clicked on reserve button")
sleep(5)

# Switch to new tab
window_handles = driver.window_handles
driver.switch_to.window(window_handles[-1])
print("Switched to new tab")

# 1. Select date '10'
date_input = driver.find_element(By.XPATH, "//input[@id='date']")
assert date_input.is_displayed(), "Date input not visible"
date_input.click()
date_option = driver.find_element(By.XPATH, "//a[normalize-space()='10']")
assert date_option.is_displayed(), "Date option '10' not visible"
date_option.click()
print("Selected date '10'")
sleep(2)

# 2. Enter term '3'
term_input = driver.find_element(By.XPATH, "//input[@id='term']")
assert term_input.is_displayed(), "Term input not visible"
term_input.click()
term_input.clear()
term_input.send_keys("3")
print("Entered term '3'")
sleep(2)

# 3. Enter head-count '2'
head_count_input = driver.find_element(By.XPATH, "//input[@id='head-count']")
assert head_count_input.is_displayed(), "Head-count input not visible"
head_count_input.click()
head_count_input.clear()
head_count_input.send_keys("2")
print("Entered head-count '2'")
sleep(2)

# 4. Tick checkboxes
breakfast_checkbox = driver.find_element(By.XPATH, "//input[@id='breakfast']")
early_checkin_checkbox = driver.find_element(By.XPATH, "//input[@id='early-check-in']")
sightseeing_checkbox = driver.find_element(By.XPATH, "//input[@id='sightseeing']")
assert breakfast_checkbox.is_displayed(), "Breakfast checkbox not visible"
assert early_checkin_checkbox.is_displayed(), "Early check-in checkbox not visible"
assert sightseeing_checkbox.is_displayed(), "Sightseeing checkbox not visible"
breakfast_checkbox.click()
early_checkin_checkbox.click()
sightseeing_checkbox.click()
print("Checked breakfast, early check-in, and sightseeing")
sleep(2)

# 5. Enter username
username_input = driver.find_element(By.XPATH, "//input[@id='username']")
assert username_input.is_displayed(), "Username input not visible"
username_input.click()
username_input.send_keys("john wick")
driver.execute_script("window.scrollBy(0, 200);")
print("Entered username 'john wick' and scrolled down")
sleep(2)

# 6. Select contact method
contact_dropdown = driver.find_element(By.XPATH, "//select[@id='contact']")
assert contact_dropdown.is_displayed(), "Contact dropdown not visible"
select = Select(contact_dropdown)
select.select_by_value("email")
print("Selected contact method 'email'")
sleep(2)

# 7. Enter email
email_input = driver.find_element(By.XPATH, "//input[@id='email']")
assert email_input.is_displayed(), "Email input not visible"
email_input.click()
email_input.send_keys("johnwick@example.com")
print("Entered email 'johnwick@example.com'")
sleep(2)

# 8. Enter comment
comment_textarea = driver.find_element(By.XPATH, "//textarea[@id='comment']")
assert comment_textarea.is_displayed(), "Comment textarea not visible"
comment_textarea.click()
comment_textarea.send_keys("this is testing")
print("Entered comment 'this is testing'")
sleep(2)
driver.execute_script("window.scrollBy(0, -400);")
print("Scrolled up slightly")

# Submit reservation
reservation = driver.find_element(By.XPATH, "//button[@id='submit-button']")
assert reservation.is_displayed(), "Submit button not visible"
reservation.click()
print("Clicked on 'Submit' button")
sleep(2)

submit = driver.find_element(By.XPATH, "//button[normalize-space()='Submit Reservation']")
assert submit.is_displayed(), "Final submit button not visible"
submit.click()
print("Final submit button is visible")
sleep(5)
alert_message=driver.find_element(By.XPATH, "//button[normalize-space()='Close']")
assert alert_message.is_displayed(), "Alert message not visible"
alert_message.click()
print("Alert message is visible")
sleep(5)


driver.quit()
print("Test completed and browser closed")